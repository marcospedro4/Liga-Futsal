package com.example.Liga_Futsal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LigaFutsalApplication {

	public static void main(String[] args) {
		SpringApplication.run(LigaFutsalApplication.class, args);
	}

}
