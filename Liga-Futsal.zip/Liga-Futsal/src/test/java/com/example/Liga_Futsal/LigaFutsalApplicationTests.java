package com.example.Liga_Futsal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LigaFutsalApplicationTests {

	@Test
	void contextLoads() {
	}

}
