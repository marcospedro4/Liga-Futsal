import React, {useEffect, useState} from 'react';
import { SafeAreaView, View, Text, TextInput, Button, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

const API_BASE = 'http://10.0.2.2:8080/api/v1'; // for Android emulator; use localhost for iOS simulator or device IP for real device

export default function App() {
  const [times, setTimes] = useState([]);
  const [nome, setNome] = useState('');
  const [cidade, setCidade] = useState('');
  const [tecnico, setTecnico] = useState('');

  useEffect(()=>{ fetchTimes() },[]);

  function fetchTimes(){
    fetch(`${API_BASE}/times`).then(r=>r.json()).then(setTimes).catch(console.error);
  }

  function criar(){
    fetch(`${API_BASE}/times`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nome,cidade,tecnico})})
      .then(r=>r.json()).then(()=>{ setNome(''); setCidade(''); setTecnico(''); fetchTimes() }).catch(err=>alert(JSON.stringify(err)));
  }

  function remover(id){
    fetch(`${API_BASE}/times/${id}`,{method:'DELETE'}).then(()=>fetchTimes());
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Liga Futsal - Mobile</Text>
      <TextInput placeholder='Nome' value={nome} onChangeText={setNome} style={styles.input}/>
      <TextInput placeholder='Cidade' value={cidade} onChangeText={setCidade} style={styles.input}/>
      <TextInput placeholder='Técnico' value={tecnico} onChangeText={setTecnico} style={styles.input}/>
      <Button title='Criar Time' onPress={criar} />
      <FlatList data={times} keyExtractor={item=>String(item.id)} renderItem={({item})=>(
        <View style={styles.item}>
          <Text>{item.nome} - {item.cidade}</Text>
          <TouchableOpacity onPress={()=>remover(item.id)} style={styles.btn}><Text>Remover</Text></TouchableOpacity>
        </View>
      )} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:16,backgroundColor:'#fff'},
  title:{fontSize:18,fontWeight:'bold',marginBottom:12},
  input:{borderWidth:1,borderColor:'#ccc',padding:8,marginBottom:8},
  item:{padding:8,borderBottomWidth:1,borderColor:'#eee',flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  btn:{backgroundColor:'#eee',padding:6,borderRadius:4}
});
