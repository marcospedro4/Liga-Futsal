# Liga Futsal - Mobile (Expo)

Este é um esqueleto de app React Native com Expo para consumir a API da liga de futsal.

Observações de rede:
- Em emulador Android use `API_BASE = 'http://10.0.2.2:8080/api/v1'`
- Em iOS simulator use `http://localhost:8080/api/v1`
- Em dispositivo físico substitua por `http://<SEU_IP_LOCAL>:8080/api/v1`

Para rodar:
1. Instale o Expo CLI: `npm install -g expo-cli`
2. Dentro da pasta do app: `npm install`
3. `npm start` e abra no emulador ou no aplicativo Expo Go.
