# Frontends para Liga Futsal
Contém duas pastas:
- web-react: app React + Vite (navegação simples e CRUD para Times/Jogadores/Árbitros)
- mobile-react-native-expo: app Expo (exemplo básico para Times)

Ajuste os endpoints (API_BASE) para `http://localhost:8080/api/v1` ou IP da sua máquina conforme necessário.
