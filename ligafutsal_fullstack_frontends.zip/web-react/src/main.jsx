import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import App from './App'
import Times from './pages/Times'
import Jogadores from './pages/Jogadores'
import Arbitros from './pages/Arbitros'
import './styles.css'

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <nav className='nav'>
      <Link to='/'>Home</Link> | <Link to='/times'>Times</Link> | <Link to='/jogadores'>Jogadores</Link> | <Link to='/arbitros'>Árbitros</Link>
    </nav>
    <Routes>
      <Route path='/' element={<App />} />
      <Route path='/times' element={<Times />} />
      <Route path='/jogadores' element={<Jogadores />} />
      <Route path='/arbitros' element={<Arbitros />} />
    </Routes>
  </BrowserRouter>
)
