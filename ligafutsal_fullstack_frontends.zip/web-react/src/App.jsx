import React from 'react'
export default function App(){ 
  return (
    <div className='container'>
      <h1>Liga Futsal - Portal Administrativo</h1>
      <p>Front-end simples (React + Vite). Configure a API base em <code>src/config.js</code>.</p>
    </div>
  )
}
