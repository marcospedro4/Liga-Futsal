import React, {useEffect, useState} from 'react'
import { API_BASE } from '../config'

export default function Arbitros(){
  const [arbitros,setArbitros] = useState([])
  const [form,setForm] = useState({nome:'',cpf:'',registroFederacao:''})

  useEffect(()=>{ fetchArb() },[])
  function fetchArb(){ fetch(`${API_BASE}/arbitros`).then(r=>r.json()).then(setArbitros).catch(console.error) }

  function handleChange(e){ setForm({...form,[e.target.name]: e.target.value}) }
  function create(e){ e.preventDefault(); fetch(`${API_BASE}/arbitros`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)}).then(r=>r.json()).then(()=>{ setForm({nome:'',cpf:'',registroFederacao:''}); fetchArb() }).catch(err=>alert(JSON.stringify(err))) }
  function del(id){ if(!confirm('Remover árbitro?')) return; fetch(`${API_BASE}/arbitros/${id}`,{method:'DELETE'}).then(()=>fetchArb()) }

  return (
    <div className='container'>
      <h2>Árbitros</h2>
      <form onSubmit={create}>
        <input name='nome' placeholder='Nome' value={form.nome} onChange={handleChange} required />
        <input name='cpf' placeholder='CPF' value={form.cpf} onChange={handleChange} required />
        <input name='registroFederacao' placeholder='Registro Federação' value={form.registroFederacao} onChange={handleChange} required />
        <button type='submit'>Criar</button>
      </form>
      <hr/>
      <table>
        <thead><tr><th>ID</th><th>Nome</th><th>CPF</th><th>Registro</th><th>Ações</th></tr></thead>
        <tbody>
          {arbitros.map(a=>(<tr key={a.id}><td>{a.id}</td><td>{a.nome}</td><td>{a.cpf}</td><td>{a.registroFederacao}</td><td><button onClick={()=>del(a.id)}>Remover</button></td></tr>))}
        </tbody>
      </table>
    </div>
  )
}
