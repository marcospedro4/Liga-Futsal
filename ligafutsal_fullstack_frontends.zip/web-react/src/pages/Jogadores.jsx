import React, {useEffect, useState} from 'react'
import { API_BASE } from '../config'

export default function Jogadores(){
  const [jogadores,setJogadores] = useState([])
  const [times,setTimes] = useState([])
  const [form,setForm] = useState({nome:'',dataNascimento:'',posicao:'',numeroCamisa:'',time:{id:''}})

  useEffect(()=>{ fetchJog(); fetchTimes() },[])

  function fetchJog(){ fetch(`${API_BASE}/jogadores`).then(r=>r.json()).then(setJogadores).catch(console.error) }
  function fetchTimes(){ fetch(`${API_BASE}/times`).then(r=>r.json()).then(setTimes).catch(console.error) }

  function handleChange(e){
    const {name,value} = e.target
    if(name==='timeId') setForm({...form,time:{id: value}})
    else setForm({...form,[name]: value})
  }

  function create(e){
    e.preventDefault()
    const payload = {...form, numeroCamisa: parseInt(form.numeroCamisa||0) }
    fetch(`${API_BASE}/jogadores`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
      .then(r=>{ if(!r.ok) return r.json().then(err=>Promise.reject(err)); return r.json() })
      .then(()=>{ setForm({nome:'',dataNascimento:'',posicao:'',numeroCamisa:'',time:{id:''}}); fetchJog() })
      .catch(err=>alert(JSON.stringify(err)))
  }

  function del(id){ if(!confirm('Remover jogador?')) return; fetch(`${API_BASE}/jogadores/${id}`,{method:'DELETE'}).then(()=>fetchJog()) }

  return (
    <div className='container'>
      <h2>Jogadores</h2>
      <form onSubmit={create}>
        <input name='nome' placeholder='Nome' value={form.nome} onChange={handleChange} required />
        <input name='dataNascimento' placeholder='YYYY-MM-DD' value={form.dataNascimento} onChange={handleChange} required />
        <input name='posicao' placeholder='Posição' value={form.posicao} onChange={handleChange} required />
        <input name='numeroCamisa' placeholder='Número' value={form.numeroCamisa} onChange={handleChange} required />
        <select name='timeId' value={form.time.id} onChange={handleChange} required>
          <option value=''>-- selecione time --</option>
          {times.map(t=>(<option key={t.id} value={t.id}>{t.nome}</option>))}
        </select>
        <button type='submit'>Criar</button>
      </form>
      <hr/>
      <table>
        <thead><tr><th>ID</th><th>Nome</th><th>Data Nasc</th><th>Posição</th><th>#</th><th>Time</th><th>Ações</th></tr></thead>
        <tbody>
          {jogadores.map(j=>(<tr key={j.id}><td>{j.id}</td><td>{j.nome}</td><td>{j.dataNascimento}</td><td>{j.posicao}</td><td>{j.numeroCamisa}</td><td>{j.time?.nome}</td><td><button onClick={()=>del(j.id)}>Remover</button></td></tr>))}
        </tbody>
      </table>
    </div>
  )
}
