import React, {useEffect, useState} from 'react'
import { API_BASE } from '../config'

export default function Times(){
  const [times,setTimes] = useState([])
  const [form,setForm] = useState({nome:'',cidade:'',tecnico:''})

  useEffect(()=>{ fetchTimes() },[])

  function fetchTimes(){
    fetch(`${API_BASE}/times`).then(r=>r.json()).then(setTimes).catch(console.error)
  }

  function handleChange(e){
    setForm({...form,[e.target.name]: e.target.value})
  }

  function createTime(e){
    e.preventDefault()
    fetch(`${API_BASE}/times`,{
      method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)
    }).then(r=>{ if(!r.ok) return r.json().then(err=>Promise.reject(err)); return r.json() })
      .then(()=>{ setForm({nome:'',cidade:'',tecnico:''}); fetchTimes() })
      .catch(err=>alert(JSON.stringify(err)))
  }

  function del(id){
    if(!confirm('Remover time?')) return
    fetch(`${API_BASE}/times/${id}`,{method:'DELETE'}).then(()=>fetchTimes())
  }

  return (
    <div className='container'>
      <h2>Times</h2>
      <form onSubmit={createTime}>
        <input name='nome' placeholder='Nome' value={form.nome} onChange={handleChange} required />
        <input name='cidade' placeholder='Cidade' value={form.cidade} onChange={handleChange} required />
        <input name='tecnico' placeholder='Técnico' value={form.tecnico} onChange={handleChange} required />
        <button type='submit'>Criar</button>
      </form>
      <hr/>
      <table>
        <thead><tr><th>ID</th><th>Nome</th><th>Cidade</th><th>Técnico</th><th>Ações</th></tr></thead>
        <tbody>
          {times.map(t=>(<tr key={t.id}><td>{t.id}</td><td>{t.nome}</td><td>{t.cidade}</td><td>{t.tecnico}</td><td><button onClick={()=>del(t.id)}>Remover</button></td></tr>))}
        </tbody>
      </table>
    </div>
  )
}
